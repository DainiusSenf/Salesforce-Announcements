/**
 * Created by daini on 19/01/31.
 */
({
    loadAnnouncement : function(component, event, helper) {
        component.set("v.loaded", false);

        var action = component.get("c.getLatestAnnouncement");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var announcement = response.getReturnValue();

                component.set("v.announcement", announcement);
                component.set("v.loaded", true);
            } else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                        helper.errorToast(errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
                component.set("v.loaded", true);
            }
        });
        $A.enqueueAction(action);
    }
})