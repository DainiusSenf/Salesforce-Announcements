/**
 * Created by daini on 19/01/31.
 */
({
    errorToast : function(errorMsg) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Failure!",
            "message": errorMsg,
            "type": "error"
        });
        toastEvent.fire();
    }
})