/**
 * Created by daini on 19/02/01.
 */
({
    initRecordData : function(component, event, helper) {
        if (event.getParams().changeType === "LOADED")
        {
            var announcement = component.get("v.simpleRecord");
            if(announcement && announcement.Profile_Group__c)
            {
                component.set("v.profiles", announcement.Profile_Group__c.split(","));
            }
        }
    }
})